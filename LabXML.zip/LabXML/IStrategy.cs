﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LabXML
{
    interface IRecordStrategy
    {
        List<VinylRecords> SearchRecords(VinylRecords vinylRecords, string path);
    }
}
