﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

namespace LabXML
{
    class RecordDOM : IRecordStrategy
    {
        private string GetFilterString(VinylRecords vinylRecords)
        {
            string filter = "//record";
            bool fl = false;

            if (vinylRecords.title != "" || vinylRecords.author != "" || vinylRecords.label != "" || vinylRecords.year != "" || vinylRecords.country != "")
            {
                filter += "[";



                if (vinylRecords.title != "")
                {
                    filter += @"@title=""" + vinylRecords.title + @"""";
                    fl = true;
                }
                if ((fl) && (vinylRecords.author != "" || vinylRecords.label != "" || vinylRecords.year != "" || vinylRecords.country != ""))
                {
                    filter += " and ";
                    fl = false;
                }
                if (vinylRecords.label != "")
                {
                    filter += @"@label=""" + vinylRecords.label + @"""";
                    fl = true;
                }


                if ((fl) && (vinylRecords.author != "" || vinylRecords.year != "" || vinylRecords.country != ""))
                {
                    filter += " and ";
                    fl = false;
                }
                if (vinylRecords.author != "")
                {
                    filter += @"@author=""" + vinylRecords.author + @"""";
                    fl = true;

                }

                if ((fl) && (vinylRecords.year != "" || vinylRecords.country != ""))
                {
                    filter += " and ";
                    fl = false;
                }
                if (vinylRecords.year != "")
                {
                    filter += @"@year=""" + vinylRecords.year + @"""";
                    fl = true;
                }


                if ((fl) && (vinylRecords.country != ""))
                {
                    filter += " and ";
                }

                if (vinylRecords.country != "")
                {
                    filter += @"@country=""" + vinylRecords.country + @"""";
                }
                filter += "]";
            }

            return filter;
        }

    public List<VinylRecords> SearchRecords(VinylRecords vinylRecords, string path)
        {
            List<VinylRecords> newVinylRecords = new List<VinylRecords>();

            XmlDocument document = new XmlDocument();
            document.Load(path);
            string filter = GetFilterString(vinylRecords);
           

            XmlNodeList nodes = document.SelectNodes(filter);
            foreach(XmlNode n in nodes)
            {
                VinylRecords vr = new VinylRecords();
                
                vr.title = n.Attributes.GetNamedItem("title").InnerText;
                vr.label = n.Attributes.GetNamedItem("label").InnerText;
                vr.author = n.Attributes.GetNamedItem("author").InnerText;
                vr.year = n.Attributes.GetNamedItem("year").InnerText;
                vr.country = n.Attributes.GetNamedItem("country").InnerText;

                newVinylRecords.Add(vr);
            }

            
            return newVinylRecords;
        }
    }
}
