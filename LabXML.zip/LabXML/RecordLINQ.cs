﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace LabXML
{
    class RecordLINQ : IRecordStrategy
    {
        List<VinylRecords> IRecordStrategy.SearchRecords(VinylRecords vinylRecords, string path)
        {
            List<VinylRecords> newVinylRecords = new List<VinylRecords>();
            var document = XDocument.Load(path);

            var result = from obj in document.Descendants("record")
                         where
                         (
                         (obj.Attribute("title").Value.Equals(vinylRecords.title) || vinylRecords.title.Equals(String.Empty)) &&
                         (obj.Attribute("author").Value.Equals(vinylRecords.author) || vinylRecords.author.Equals(String.Empty)) &&
                         (obj.Attribute("label").Value.Equals(vinylRecords.author) || vinylRecords.label.Equals(String.Empty)) &&
                         (obj.Attribute("year").Value.Equals(vinylRecords.author) || vinylRecords.year.Equals(String.Empty)) &&
                         (obj.Attribute("country").Value.Equals(vinylRecords.author) || vinylRecords.country.Equals(String.Empty))
                         )
                         select new 
                         {
                             title=(string)obj.Attribute("title").Value,
                             author =(string)obj.Attribute("author").Value,
                             label=(string)obj.Attribute("label").Value,
                             year=(string)obj.Attribute("year").Value,
                             country=(string)obj.Attribute("country").Value

                         };
                         
            foreach(var i in result)
            {
                VinylRecords myVinylRecords = new VinylRecords();
                myVinylRecords.title = i.title;
                myVinylRecords.author = i.author;
                myVinylRecords.label = i.label;
                myVinylRecords.year = i.year;
                myVinylRecords.country = i.country;
            }

            return newVinylRecords;
        }
    }
}
