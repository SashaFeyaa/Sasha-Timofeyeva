﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

namespace LabXML
{
    class RecordSAX : IRecordStrategy { 
    
public List<VinylRecords> SearchRecords(VinylRecords vinylRecords, string path)
        {
            List<VinylRecords> newVinylRecords = new List<VinylRecords>();
            var xmlReader = new XmlTextReader(path);

            while (xmlReader.Read())
            {
                if (xmlReader.HasAttributes)
                {
                    while (xmlReader.MoveToNextAttribute())
                    {
                        string title = "";
                        string author = "";
                        string label = "";
                        string year = "";
                        string country = "";

                        if(xmlReader.Name.Equals("title")&&(xmlReader.Value.Equals(vinylRecords.title) || vinylRecords.title.Equals(String.Empty)))
                        {
                            title = xmlReader.Value;
                            xmlReader.MoveToNextAttribute();

                            if(xmlReader.Name.Equals("author") && (xmlReader.Value.Equals(vinylRecords.author) || vinylRecords.author.Equals(String.Empty)))
                            {
                                author = xmlReader.Value;
                                xmlReader.MoveToNextAttribute();

                                if (xmlReader.Name.Equals("label") && (xmlReader.Value.Equals(vinylRecords.label) || vinylRecords.label.Equals(String.Empty)))
                                {
                                    label = xmlReader.Value;
                                    xmlReader.MoveToNextAttribute();

                                    if (xmlReader.Name.Equals("year") && (xmlReader.Value.Equals(vinylRecords.year) || vinylRecords.year.Equals(String.Empty)))
                                    {

                                        year = xmlReader.Value;
                                        xmlReader.MoveToNextAttribute();

                                        if (xmlReader.Name.Equals("country") && (xmlReader.Value.Equals(vinylRecords.country) || vinylRecords.country.Equals(String.Empty)))
                                        {

                                            country = xmlReader.Value;
                                            
                                        }
                                    }
                                }
                            }

                        }

                        if(title!= ""&& author!= "" && label!= "" && year!= "" && country!= "")
                        {
                            VinylRecords myVinylRecords = new VinylRecords();
                            myVinylRecords.title = title;
                            myVinylRecords.author = author;
                            myVinylRecords.label = label;
                            myVinylRecords.year = year;
                            myVinylRecords.country = country;

                            newVinylRecords.Add(myVinylRecords);
                        }
                    }
                }


            }
            xmlReader.Close();
            return newVinylRecords;
        }
    }
}
