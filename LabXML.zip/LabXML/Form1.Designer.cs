﻿namespace LabXML
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnTransform = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.radioBtnLINQ = new System.Windows.Forms.RadioButton();
            this.radioBtnSAX = new System.Windows.Forms.RadioButton();
            this.radioBtnDOM = new System.Windows.Forms.RadioButton();
            this.cBoxTitle = new System.Windows.Forms.ComboBox();
            this.cBoxAuthor = new System.Windows.Forms.ComboBox();
            this.cBoxLabel = new System.Windows.Forms.ComboBox();
            this.cBoxYear = new System.Windows.Forms.ComboBox();
            this.cBoxCountry = new System.Windows.Forms.ComboBox();
            this.checkBoxTitle = new System.Windows.Forms.CheckBox();
            this.checkBoxAuthor = new System.Windows.Forms.CheckBox();
            this.checkBoxLabel = new System.Windows.Forms.CheckBox();
            this.checkBoxYear = new System.Windows.Forms.CheckBox();
            this.checkBoxCountry = new System.Windows.Forms.CheckBox();
            this.richTextBoxVinyl = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // btnTransform
            // 
            this.btnTransform.Location = new System.Drawing.Point(126, 381);
            this.btnTransform.Name = "btnTransform";
            this.btnTransform.Size = new System.Drawing.Size(172, 34);
            this.btnTransform.TabIndex = 0;
            this.btnTransform.Text = "Transforn to HTML";
            this.btnTransform.UseVisualStyleBackColor = true;
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(14, 364);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(74, 34);
            this.btnClear.TabIndex = 1;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(14, 404);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 34);
            this.btnSearch.TabIndex = 2;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.button3_Click);
            // 
            // radioBtnLINQ
            // 
            this.radioBtnLINQ.AutoSize = true;
            this.radioBtnLINQ.Location = new System.Drawing.Point(14, 306);
            this.radioBtnLINQ.Name = "radioBtnLINQ";
            this.radioBtnLINQ.Size = new System.Drawing.Size(139, 29);
            this.radioBtnLINQ.TabIndex = 3;
            this.radioBtnLINQ.TabStop = true;
            this.radioBtnLINQ.Text = "LINQ to XML";
            this.radioBtnLINQ.UseVisualStyleBackColor = true;
            this.radioBtnLINQ.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // radioBtnSAX
            // 
            this.radioBtnSAX.AutoSize = true;
            this.radioBtnSAX.Location = new System.Drawing.Point(14, 271);
            this.radioBtnSAX.Name = "radioBtnSAX";
            this.radioBtnSAX.Size = new System.Drawing.Size(70, 29);
            this.radioBtnSAX.TabIndex = 4;
            this.radioBtnSAX.TabStop = true;
            this.radioBtnSAX.Text = "SAX";
            this.radioBtnSAX.UseVisualStyleBackColor = true;
            this.radioBtnSAX.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // radioBtnDOM
            // 
            this.radioBtnDOM.AutoSize = true;
            this.radioBtnDOM.Location = new System.Drawing.Point(14, 236);
            this.radioBtnDOM.Name = "radioBtnDOM";
            this.radioBtnDOM.Size = new System.Drawing.Size(80, 29);
            this.radioBtnDOM.TabIndex = 5;
            this.radioBtnDOM.TabStop = true;
            this.radioBtnDOM.Text = "DOM";
            this.radioBtnDOM.UseVisualStyleBackColor = true;
            this.radioBtnDOM.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // cBoxTitle
            // 
            this.cBoxTitle.FormattingEnabled = true;
            this.cBoxTitle.Location = new System.Drawing.Point(116, 29);
            this.cBoxTitle.Name = "cBoxTitle";
            this.cBoxTitle.Size = new System.Drawing.Size(182, 33);
            this.cBoxTitle.TabIndex = 6;
            this.cBoxTitle.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // cBoxAuthor
            // 
            this.cBoxAuthor.FormattingEnabled = true;
            this.cBoxAuthor.Location = new System.Drawing.Point(116, 66);
            this.cBoxAuthor.Name = "cBoxAuthor";
            this.cBoxAuthor.Size = new System.Drawing.Size(182, 33);
            this.cBoxAuthor.TabIndex = 7;
            // 
            // cBoxLabel
            // 
            this.cBoxLabel.FormattingEnabled = true;
            this.cBoxLabel.Location = new System.Drawing.Point(116, 105);
            this.cBoxLabel.Name = "cBoxLabel";
            this.cBoxLabel.Size = new System.Drawing.Size(182, 33);
            this.cBoxLabel.TabIndex = 8;
            // 
            // cBoxYear
            // 
            this.cBoxYear.FormattingEnabled = true;
            this.cBoxYear.Location = new System.Drawing.Point(116, 144);
            this.cBoxYear.Name = "cBoxYear";
            this.cBoxYear.Size = new System.Drawing.Size(182, 33);
            this.cBoxYear.TabIndex = 9;
            // 
            // cBoxCountry
            // 
            this.cBoxCountry.FormattingEnabled = true;
            this.cBoxCountry.Location = new System.Drawing.Point(116, 181);
            this.cBoxCountry.Name = "cBoxCountry";
            this.cBoxCountry.Size = new System.Drawing.Size(182, 33);
            this.cBoxCountry.TabIndex = 10;
            this.cBoxCountry.SelectedIndexChanged += new System.EventHandler(this.comboBox5_SelectedIndexChanged);
            // 
            // checkBoxTitle
            // 
            this.checkBoxTitle.AutoSize = true;
            this.checkBoxTitle.Location = new System.Drawing.Point(14, 35);
            this.checkBoxTitle.Name = "checkBoxTitle";
            this.checkBoxTitle.Size = new System.Drawing.Size(67, 29);
            this.checkBoxTitle.TabIndex = 11;
            this.checkBoxTitle.Text = "title";
            this.checkBoxTitle.UseVisualStyleBackColor = true;
            this.checkBoxTitle.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // checkBoxAuthor
            // 
            this.checkBoxAuthor.AutoSize = true;
            this.checkBoxAuthor.Location = new System.Drawing.Point(14, 70);
            this.checkBoxAuthor.Name = "checkBoxAuthor";
            this.checkBoxAuthor.Size = new System.Drawing.Size(90, 29);
            this.checkBoxAuthor.TabIndex = 12;
            this.checkBoxAuthor.Text = "author";
            this.checkBoxAuthor.UseVisualStyleBackColor = true;
            // 
            // checkBoxLabel
            // 
            this.checkBoxLabel.AutoSize = true;
            this.checkBoxLabel.Location = new System.Drawing.Point(14, 111);
            this.checkBoxLabel.Name = "checkBoxLabel";
            this.checkBoxLabel.Size = new System.Drawing.Size(75, 29);
            this.checkBoxLabel.TabIndex = 13;
            this.checkBoxLabel.Text = "label";
            this.checkBoxLabel.UseVisualStyleBackColor = true;
            // 
            // checkBoxYear
            // 
            this.checkBoxYear.AutoSize = true;
            this.checkBoxYear.Location = new System.Drawing.Point(14, 146);
            this.checkBoxYear.Name = "checkBoxYear";
            this.checkBoxYear.Size = new System.Drawing.Size(71, 29);
            this.checkBoxYear.TabIndex = 14;
            this.checkBoxYear.Text = "year";
            this.checkBoxYear.UseVisualStyleBackColor = true;
            // 
            // checkBoxCountry
            // 
            this.checkBoxCountry.AutoSize = true;
            this.checkBoxCountry.Location = new System.Drawing.Point(14, 181);
            this.checkBoxCountry.Name = "checkBoxCountry";
            this.checkBoxCountry.Size = new System.Drawing.Size(98, 29);
            this.checkBoxCountry.TabIndex = 15;
            this.checkBoxCountry.Text = "country";
            this.checkBoxCountry.UseVisualStyleBackColor = true;
            // 
            // richTextBoxVinyl
            // 
            this.richTextBoxVinyl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.richTextBoxVinyl.Location = new System.Drawing.Point(343, 25);
            this.richTextBoxVinyl.Name = "richTextBoxVinyl";
            this.richTextBoxVinyl.Size = new System.Drawing.Size(349, 390);
            this.richTextBoxVinyl.TabIndex = 16;
            this.richTextBoxVinyl.Text = "";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(725, 450);
            this.Controls.Add(this.richTextBoxVinyl);
            this.Controls.Add(this.checkBoxCountry);
            this.Controls.Add(this.checkBoxYear);
            this.Controls.Add(this.checkBoxLabel);
            this.Controls.Add(this.checkBoxAuthor);
            this.Controls.Add(this.checkBoxTitle);
            this.Controls.Add(this.cBoxCountry);
            this.Controls.Add(this.cBoxYear);
            this.Controls.Add(this.cBoxLabel);
            this.Controls.Add(this.cBoxAuthor);
            this.Controls.Add(this.cBoxTitle);
            this.Controls.Add(this.radioBtnDOM);
            this.Controls.Add(this.radioBtnSAX);
            this.Controls.Add(this.radioBtnLINQ);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnTransform);
            this.Name = "Form1";
            this.Text = "Лабораторна робота №2 ";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnTransform;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.RadioButton radioBtnLINQ;
        private System.Windows.Forms.RadioButton radioBtnSAX;
        private System.Windows.Forms.RadioButton radioBtnDOM;
        private System.Windows.Forms.ComboBox cBoxTitle;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox cBoxLabel;
        private System.Windows.Forms.ComboBox cBoxYear;
        private System.Windows.Forms.ComboBox cBoxCountry;
        private System.Windows.Forms.CheckBox checkBoxTitle;
        private System.Windows.Forms.CheckBox checkBoxAuthor;
        private System.Windows.Forms.CheckBox checkBoxLabel;
        private System.Windows.Forms.CheckBox checkBoxYear;
        private System.Windows.Forms.CheckBox checkBoxCountry;
        private System.Windows.Forms.RichTextBox richTextBoxVinyl;
        private System.Windows.Forms.ComboBox cBoxAuthor;
    }
}

