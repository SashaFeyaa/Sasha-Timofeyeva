﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using System.Xml.Xsl;

namespace LabXML
{
    public partial class Form1 : Form
    {
        string path = @"C:\Users\Asus\Source\Repos\LabXML\myXML.xml";
        List<VinylRecords> final = new List<VinylRecords>();

        public Form1()
        {
            InitializeComponent();
            FillComboBoxes();
      

        }

        private void FillComboBoxes()
        {
            FillTitlesComboBox();
            FillAuthorsComboBox();
            FillLabelsComboBox();
            FillYearsComboBox();
            FillCountriesComboBox();
        }

        private void FillAuthorsComboBox()
        {
            var document = XDocument.Load(path);

            var authors = (from obj in document.Descendants("record")
                          select new
                          {
                              author = (string)obj.Attribute("author").Value
                          }).Distinct().ToList();

            foreach (var a in authors)
            {
                cBoxAuthor.Items.Add(a.author);
            }
            cBoxAuthor.SelectedIndex = 0;
        }

        //cBoxAuthor
        private void FillTitlesComboBox()
        {
            var document = XDocument.Load(path);

            var titles = (from obj in document.Descendants("record")
                          select new
                          {
                              title = (string)obj.Attribute("title").Value
                          }).Distinct().ToList();

            foreach (var t in titles)
            {
                cBoxTitle.Items.Add(t.title);
            }
            cBoxTitle.SelectedIndex = 0;
        }

        private void FillYearsComboBox()
        {
            var document = XDocument.Load(path);

            var years = (from obj in document.Descendants("record")
                          select new
                          {
                              year = (string)obj.Attribute("year").Value
                          }).Distinct().ToList();

            foreach (var t in years)
            {
                cBoxYear.Items.Add(t.year);
            }
            cBoxYear.SelectedIndex = 0;
        }

        private void FillLabelsComboBox()
        {
            var document = XDocument.Load(path);

            var labels = (from obj in document.Descendants("record")
                          select new
                          {
                              label = (string)obj.Attribute("label").Value
                          }).Distinct().ToList();

            foreach (var t in labels)
            {
                cBoxLabel.Items.Add(t.label);
            }
            cBoxLabel.SelectedIndex = 0;
        }

        private void FillCountriesComboBox()
        {
            var document = XDocument.Load(path);

            var countries = (from obj in document.Descendants("record")
                          select new
                          {
                              country = (string)obj.Attribute("country").Value
                          }).Distinct().ToList();

            foreach (var t in countries)
            {
                cBoxCountry.Items.Add(t.country);
            }
            cBoxCountry.SelectedIndex = 0;
        }


        private void button2_Click(object sender, EventArgs e)
        {
            richTextBoxVinyl.Clear();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void comboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }
        private void PrintVinylRecordList(List<VinylRecords> lvr)
        {
            richTextBoxVinyl.Clear();
            string text = "";
            foreach(var vr in lvr)
            {
                text +=  vr.title;
                text += "\n";
                text += "\t" + vr.author;
                text += "\n";
                text += "\t" + vr.label;
                text += "\n";
                text += "\t" + vr.year;
                text += "\n";
                text += "\t" + vr.country;
                text += "\n";
                text += "\n";
            }

            richTextBoxVinyl.Text = text;
        }

        private void SearchVinyl()
        {
            IRecordStrategy rs;
            VinylRecords vr = new VinylRecords();
            List<VinylRecords> lvr = new List<VinylRecords>(); ;

            if (checkBoxAuthor.Checked)
            {
                vr.author = cBoxAuthor.Text;
            }

            if (checkBoxCountry.Checked)
            {
                vr.country = cBoxCountry.Text;
            }

            if (checkBoxTitle.Checked)
            {
                vr.title = cBoxTitle.Text;
            }

            if (checkBoxYear.Checked)
            {
                vr.year = cBoxYear.Text;
            }

            if (checkBoxLabel.Checked)
            {
                vr.author = cBoxAuthor.Text;
            }

            if (radioBtnDOM.Checked)
            {
                rs = new RecordDOM();
                lvr = rs.SearchRecords(vr, path);
            }
            else
            {
                if (radioBtnSAX.Checked)
                {
                    rs = new RecordSAX();
                    lvr = rs.SearchRecords(vr, path);
                }
                else if(radioBtnLINQ.Checked)
                {
                    rs = new RecordLINQ();
                    lvr = rs.SearchRecords(vr, path);
                }
            }

            



            PrintVinylRecordList(lvr);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SearchVinyl();
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged_1(object sender, EventArgs e)
        {
            MyTransform();
        }

        private void MyTransform()
        {
            XslCompiledTransform xsl = new XslCompiledTransform();
            xsl.Load(@"C:\Users\Asus\Source\Repos\LabXML\XSLTFileRecords.xslt");
            string fXML = (@"C:\Users\Asus\Source\Repos\LabXML\XSLTFileRecords.xml");
            string fHTML = (@"C:\Users\Asus\Source\Repos\LabXML\XSLTFileRecords.html");
            xsl.Transform(fXML, fHTML);
        }
    }
}
