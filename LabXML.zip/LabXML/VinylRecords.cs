﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LabXML
{
    class VinylRecords
    {
        public string title { get; set; }
        public string author{ get; set; }
        public string label { get; set; }
        public string year { get; set; }
        public string country { get; set; }

        public VinylRecords() 
        {
            title = "";
            author = "";
            label = "";
            year = "";
            country = "";
        }

       



    }
}
