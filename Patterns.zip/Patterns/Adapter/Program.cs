﻿using System;
namespace AdapterExample
{
    // Система яку будемо адаптовувати
    class OldEngine
    {
        public string FourCylinders()
        {
            return "Old Engine";
        }
    }
    // Широковикористовуваний інтерфейс нової системи (специфікація до машини)
    interface INewEngine
    {
        string SixCylinders();
    }

    // Ну і власне сам двигун у новій машині
    class NewEngine : INewEngine
    {
        public string SixCylinders()
        {
            return "New interface";
        }
    }
    // Адаптер назовні виглядає як новий шестициліндровий двигун, шляхом наслідування прийнятного у 
    // системі інтерфейсу
    class Adapter : INewEngine
    {
        // Але всередині він старий
        private readonly OldEngine _adaptee;
        public Adapter(OldEngine adaptee)
        {
            _adaptee = adaptee;
        }

        // А тут відбувається вся магія: наш адаптер «перекладає»
        // функціональність із нового стандарту на старий
        public string SixCylinders()
        {
            // Якщо б була різниця 
            // то тут ми б помістили трансформатор
            return _adaptee.FourCylinders();
        }
    }

     class  CarManufacture
    {
        // Машина, яка розуміє тільки нову систему
        public static void Car(INewEngine engine)
        {
            Console.WriteLine(engine.SixCylinders());
        }
    }

    public class AdapterDemo
    {
        static void Main()
        {
            // 1) Ми можемо користуватися новою системою без проблем
            var newEngine = new NewEngine();
            CarManufacture.Car(newEngine);
            // 2) Ми повинні адаптуватися до старої системи, використовуючи адаптер
            var oldElectricitySystem = new OldEngine();
            var adapter = new Adapter(oldElectricitySystem);
            CarManufacture.Car(adapter);            
            Console.ReadKey();
        }
    }
}
