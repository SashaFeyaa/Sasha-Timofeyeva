﻿using System;
using System.Collections.Generic;

namespace Visitor_1
{

    // The Element abstract class.
    // Accept method needs to be implemented in dervied classes
    // that can be visited by Visitor.
    abstract class Element
    {
        public abstract void Accept(IVisitor visitor);
    }
    class Employee : Element
    {
        public string Name { get; set; }
        public double Salary { get; set; }
        public int PaidTimeOffDays { get; set; }

        public Employee(string name, double salary, int paidTimeOffDays)
        {
            Name = name;
            Salary = salary;
            PaidTimeOffDays = paidTimeOffDays;
        }

        public override void Accept(IVisitor visitor)
        {
            visitor.Visit(this);
        }
    }
    // A collection of Concrete Elements - here employees.
    class Employees
    {
        private List<Employee> _employees = new List<Employee>();

        public void Attach(Employee employee)
        {
            _employees.Add(employee);
        }

        public void Accept(IVisitor visitor)
        {
            foreach (Employee e in _employees)
            {
                e.Accept(visitor);
            }
            Console.WriteLine();
        }
    }
    class LineCook : Employee
    {
        public LineCook(string name, double salary, int paidTimeOffDays) : base(name, salary, paidTimeOffDays)
        {
        }
    }

    class HeadChef : Employee
    {
        public HeadChef(string name, double salary, int paidTimeOffDays) : base(name, salary, paidTimeOffDays)
        {
        }
    }

    class GeneralManager : Employee
    {
        public GeneralManager(string name, double salary, int paidTimeOffDays) : base(name, salary, paidTimeOffDays)
        {
        }
    }
    // The Visitor interface, which declares a Visit operation
    // for each ConcreteVisitor to implement.
    interface IVisitor
    {
        void Visit(Element element);
    }
    // A Concrete Visitor class: raises salary.
    class IncomeVisitor : IVisitor
    {
        private const double _raise = 1.1;
        public void Visit(Element element)
        {
            Employee employee = element as Employee;

            employee.Salary *= _raise;
            Console.WriteLine("{0} {1}'s new income: {2:C}", employee.GetType().Name, employee.Name, employee.Salary);
        }
    }
    // A Concrete Visitor class: adds extra paid time off days.
    class PaidTimeOffVisitor : IVisitor
    {
        private const int _extraDays = 3;
        public void Visit(Element element)
        {
            Employee employee = element as Employee;

            employee.PaidTimeOffDays += _extraDays;
            Console.WriteLine("{0} {1}'s new vacation days: {2}", employee.GetType().Name, employee.Name, employee.PaidTimeOffDays);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Hire several employees
            Employees employees = new Employees();
            employees.Attach(new LineCook("Ivan", 32000, 7));
            employees.Attach(new HeadChef("Petro", 69015, 21));
            employees.Attach(new GeneralManager("Anna", 78000, 24));

            // Employees are visited, being given some extra raises and paid time off days.
            employees.Accept(new IncomeVisitor());
            employees.Accept(new PaidTimeOffVisitor());

            Console.ReadKey();

        }
    }
}
