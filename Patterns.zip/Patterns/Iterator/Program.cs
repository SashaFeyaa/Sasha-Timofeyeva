﻿using System;
using System.Collections;

namespace Iterator
{
    //абстрактний клас певного набору елементів, він буде використовуватися для створення об’єкта-ітератора
    abstract class Aggregate
    {
        public abstract Iterator CreateIterator();
        public abstract int Count_Elements { get; protected set; }
        public abstract object this[int index] { get; set; }/*element[index] of the collection*/
    }

    //абстрактний клас ітератора
    abstract class Iterator
    {
        public abstract object First();
        public abstract object Next();
        public abstract bool IsDone();
        public abstract object CurrentItem();
        public abstract void Reset();
    }

    //Реалізуємо клас ConcreteAgregate, що успадковується від Aggregate
   //Він зберігатиме елементи, які ми будемо перебирати. 
    class ConcreteAggregate : Aggregate
    {
        private readonly ArrayList _items = new ArrayList();

        public override Iterator CreateIterator()

        {
            return new ConcreteIterator(this);
        }

        public override int Count_Elements
        {
            get { return _items.Count; }
            protected set { }
        }

        public override object this[int index]
        {
            get { return _items[index]; }
            set { _items.Insert(index, value); }
        }
    }

    class ConcreteIterator : Iterator
    {
        private readonly Aggregate _aggregate;
        private int _current;

        public ConcreteIterator(Aggregate aggregate)
        {
            this._aggregate = aggregate;
        }

        public override object First()
        {
            return _aggregate[0];
        }

        public override object Next()
        {
            object ret = null;

            _current++;

            if (_current < _aggregate.Count_Elements)
            {
                ret = _aggregate[_current];
            }

            return ret;
        }

        public override object CurrentItem()
        {
            return _aggregate[_current];
        }

        public override bool IsDone()
        {
            return _current >= _aggregate.Count_Elements;
        }
        public override void Reset()
        {
            _current = 0;
        }
    }




    class Program
    {
        static void Main(string[] args)
        {
            Aggregate a = new ConcreteAggregate();
            a[a.Count_Elements] = 1;
            a[a.Count_Elements] = 2;
            a[a.Count_Elements] = 3;


            Iterator i = a.CreateIterator();

            object item = i.First();
            while (!i.IsDone())
            {
                Console.WriteLine(item);
                item = i.Next();                
            }
            Console.ReadKey();
        }
    }
}
