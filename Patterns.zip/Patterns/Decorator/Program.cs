﻿using System;
namespace Decorator.Examples
{
    class MainApp
    {
        static void Main()
        {
            // Create ConcreteComponent and two Decorators
            ChristmassTree c = new ChristmassTree(200);
            c.Stand();

            ChristmassBall ball1 = new ChristmassBall("blue", 5);
            ball1.SetComponent(c);
            ball1.Stand();

            ChristmassBall ball2 = new ChristmassBall("red", 10);
            ball2.SetComponent(ball1);
            ball2.Stand();

            ChristmassGarland garland = new ChristmassGarland("miracle");
            garland.SetComponent(ball2);
            garland.Stand();
            garland.ShineMode();
            garland.Stand();
            // Wait for user
            Console.Read();
        }
    }
    // "Component"
    abstract class Tree
    {
        public abstract void Stand();
    }

    // "ConcreteComponent"
    class ChristmassTree : Tree
    {
        private int height;

        public ChristmassTree(int _height)
        {
            height = _height;
        }
        
        public override void Stand()
        {
            Console.WriteLine("Standing ChristmassTree height = {0} cm", height);
        }
    }
    // "Decorator"
    abstract class ChristmassDecoration : Tree
    {
        protected Tree component;

        public void SetComponent(Tree component)
        {
            this.component = component;
        }
        public override void Stand()
        {
            if (component != null)
            {
                component.Stand();
            }
        }
    }

    // "ConcreteDecoratorA"
    class ChristmassBall : ChristmassDecoration
    {
        private string color;
        private int diameter;

        public ChristmassBall(string _color, int _diam)
        {
            color = _color;
            diameter = _diam;
        }

        public override void Stand()
        {
            base.Stand();
            
            Console.WriteLine("{0} Toy diameter {1} is on the Tree", color, diameter);
        }
    }

    // "ConcreteDecoratorB" 
    class ChristmassGarland : ChristmassDecoration
    {
        private bool isShining = false;
        private string color;

        public ChristmassGarland(string _color)
        {
            color = _color;
        }

        public override void Stand()
        {
            base.Stand();
            Console.WriteLine("{0} Garland is shained = {1}", color, isShining);
        }
         public void ShineMode()
        {
            isShining = !(isShining);
        }
    }
}
