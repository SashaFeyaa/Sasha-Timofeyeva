﻿using System;
namespace FactoryMethodExample
{
    //абстрактний клас творця, який має абстрактний метод FactoryMethod, що приймає тип продукта
   

    public abstract class FilmProduct 
    {
        public string Name { get; set; }

        public FilmProduct(string n)
        {
            Name = n;
        }
        // фабричный метод
        abstract public Film Create();
    } //абстрактний клас продукт

    //конкретні продукти з різною реалізацією
    public class BandWFilmProduct : FilmProduct
    {
        public BandWFilmProduct(string n) : base(n)
        {
        }

        public override Film Create()
        {
            return new BandWFilm();
        }
    }

    public class CFilmProduct : FilmProduct
    {
        public CFilmProduct(string n) : base(n)
        {
        }

        public override Film Create()
        {
            return new CFilm();
        }
    }

    public class CartoonProduct : FilmProduct
    {
        public CartoonProduct(string n) : base(n)
        {
        }

        public override Film Create()
        {
            return new Cartoon();
        }
    }

    public abstract class Film { }

    public class CFilm : Film
    {
        public CFilm()
        {
            Console.WriteLine("Colored Film");
        }
    }

    public class BandWFilm: Film
    {
        public BandWFilm()
        {
            Console.WriteLine("Black and White Film");
        }
    }

    public class Cartoon : Film 
    {
        public Cartoon()
        {
            Console.WriteLine("Cartoon");
        }
    }

    class MainApp
    {
        static void Main()
        {       //створюємо творця
            FilmProduct fp = new CFilmProduct("Iron man");
            Film film = fp.Create();

            fp = new CartoonProduct("Beauty and The Beast");
            Film film2 = fp.Create();

            fp = new BandWFilmProduct("Earth");
            Film film3 = fp.Create();

            Console.ReadLine();

            Console.ReadKey();
        }
    }
}

